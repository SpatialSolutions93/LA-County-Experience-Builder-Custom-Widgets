export default {
  _widgetLabel: 'Food Provider Analysis',
}
